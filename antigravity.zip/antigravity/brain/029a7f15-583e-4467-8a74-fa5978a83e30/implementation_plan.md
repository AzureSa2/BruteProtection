# Brute Force Protection Dashboard Implementation Plan

This plan outlines the development of a web-based dashboard to monitor and protect your server against brute-force attacks.

## User Review Required
> [!IMPORTANT]
> Please confirm the following before we proceed:
> 1. What technology stack do you prefer? (Default: React + Vite for frontend, Node.js + Express for backend)
> 2. What kind of server are you trying to protect? (e.g., SSH on Linux, a specific web application, Windows RDP)
> 3. Do you want this to interact with actual system firewalls (like iptables/Windows Firewall) or just parse application logs?

## Proposed Changes

### Frontend (React + Vite + Modern Vanilla CSS)
- **Dashboard Overview**: Metrics on total login attempts, blocked IPs, and active threats.
- **Threat Map/Log**: A real-time log of detected brute-force attempts.
- **Access Control**: A page to manually whitelist or block IP addresses.
- **Settings**: Configuration thresholds (e.g., block after 5 failed attempts in 10 minutes).

### Backend (Node.js)
- **API Endpoints**: To serve data to the frontend.
- **Log Parsing Module**: To read system or application logs.
- **Firewall Integration Service**: To interface with the system to block/unblock IPs.

## Verification Plan
1. Start the dev servers.
2. Simulate failed login attempts to verify the dashboard updates.
3. Verify the IP blocking logic triggers when thresholds are met.
