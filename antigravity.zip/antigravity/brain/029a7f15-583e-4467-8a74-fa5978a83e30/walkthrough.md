# Brute Force Protection Dashboard - Walkthrough

## Overview
I have developed a highly dynamic, premium web dashboard to monitor and protect your server against brute-force attacks. Because Node.js and Python were not available on your system, this dashboard is built entirely with **Vanilla HTML, CSS, and JavaScript**. It uses an internal simulation to mock real-world brute-force attack telemetry so you can see exactly how the UI behaves.

The files are located in your workspace:
- `c:\Users\User\.gemini\antigravity\playground\solitary-coronal\brute-force-dashboard\index.html`
- `c:\Users\User\.gemini\antigravity\playground\solitary-coronal\brute-force-dashboard\styles.css`
- `c:\Users\User\.gemini\antigravity\playground\solitary-coronal\brute-force-dashboard\app.js`

## Changes Made
1. **HTML Structure (`index.html`)**: Created the semantic layout including a sidebar navigation, top bar with search and profile out-of-the-box, and four main views: Overview, Attack Logs, Blocked IPs, and Settings.
2. **Premium Styling (`styles.css`)**: Implemented a dark-mode theme utilizing glassmorphism (translucent backgrounds with blur), vibrant warning/success colors, CSS animations for new events, and customized scrollbars to give it a cutting-edge cybersecurity feel.
3. **Application Logic (`app.js`)**: Built an engine that simulates incoming log attempts every few seconds. It maintains state, pushes new "attacks" to the log table, conditionally triggers "blocks" based on a mocked threshold, and updates dynamic charts and statistics in real-time.

## Features Built
- **Live Feed & Charts**: A bar chart and critical event feed that updates every few seconds as new mock events are digested.
- **Top Metrics View**: Badges keeping track of *Total Attempts*, *Active Threats*, and *Blocked IPs*.
- **Attack Logs View**: A detailed table tracking timestamps, source IPs, target services (SSH, FTP, etc.), usernames attempted, and whether the attempt was just a failure or triggered a block.
- **Blocked IP Management**: A view for all currently blocked IPs, with a functioning "Unblock" button that dynamically removes rules and updates system counts.
- **Settings View**: Form UI dedicated to adjusting fail thresholds and block durations.

## Usage
Simply double-click the `index.html` file in your file explorer, or drag and drop it into any modern web browser (Chrome, Edge, Firefox). The simulation begins as soon as the page is ready, offering you a complete interactive demonstration of the tool's capabilities.
